# FonicsArtifact Linux – Custom Gold/Trolling WebPanel

Dieses Paket portiert die **FonicsScriptsDE Custom txAdmin/WebPanel-Dateien** aus dem bereitgestellten Windows-Artifact auf ein offizielles Linux-FXServer-Artifact.

## Wichtig
Windows-Binärdateien wie `FXServer.exe` und `.dll` können nicht direkt unter Linux verwendet werden. Deshalb enthält dieses Paket die Custom-WebPanel-/Monitor-Dateien plus Installer, der ein offizielles Linux-Artifact lädt und die Anpassungen darüber installiert.

## Ubuntu/Debian Installation

```bash
sudo apt update
sudo apt install -y curl xz-utils tar
chmod +x install.sh start.sh
export ARTIFACT_URL='HIER_DIE_OFFIZIELLE_LINUX_FXSERVER_TAR_XZ_URL'
sudo -E ./install.sh /opt/fonics-artifact
```

Die offizielle Linux-Artifact-Auswahl befindet sich unter:
https://runtime.fivem.net/artifacts/fivem/build_proot_linux/

## Start

```bash
FONICS_ARTIFACT_DIR=/opt/fonics-artifact \
SERVER_CFG=/opt/fivem/server-data/server.cfg \
./start.sh
```

## systemd optional
Passe bei Bedarf die Pfade in `fonics-fxserver.service` an und kopiere die Datei nach `/etc/systemd/system/`.

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now fonics-fxserver
sudo systemctl status fonics-fxserver
```

## Enthaltene Custom-Dateien
- Gold/Dark WebPanel-Anpassungen
- Trolling-Seite (`web/main/trolling.ejs`)
- `fonics-troll.js`
- angepasste txAdmin/Monitor-Dateien aus deinem Upload
