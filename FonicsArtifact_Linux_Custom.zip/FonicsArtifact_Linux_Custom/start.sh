#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="${FONICS_ARTIFACT_DIR:-/opt/fonics-artifact}"
SERVER_CFG="${SERVER_CFG:-/opt/fivem/server-data/server.cfg}"
cd "$BASE_DIR"
exec ./run.sh +exec "$SERVER_CFG"
