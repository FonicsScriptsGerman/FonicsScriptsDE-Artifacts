RegisterCommand('fonicstroll', function(source, args)
    if source ~= 0 then return end
    local action = tostring(args[1] or '')
    local target = tonumber(args[2] or '')
    if action == '' or not target or not GetPlayerName(target) then return end
    TriggerClientEvent('fonics:troll', target, action)
end, true)
