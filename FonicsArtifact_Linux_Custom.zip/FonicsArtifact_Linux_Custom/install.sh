#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="${1:-$PWD/FonicsArtifact}"
CUSTOM_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/custom/monitor"
ARTIFACT_URL="${ARTIFACT_URL:-}"

if [[ -z "$ARTIFACT_URL" ]]; then
  echo "FonicsArtifact Linux Installer"
  echo "Bitte setze ARTIFACT_URL auf die offizielle Linux server.tar.xz URL."
  echo "Beispiel: ARTIFACT_URL='https://runtime.fivem.net/.../fx.tar.xz' sudo -E ./install.sh /opt/fonics-artifact"
  echo "Offizielle Auswahl: https://runtime.fivem.net/artifacts/fivem/build_proot_linux/"
  exit 1
fi

command -v curl >/dev/null || { echo "curl fehlt: sudo apt install -y curl"; exit 1; }
command -v tar >/dev/null || { echo "tar fehlt: sudo apt install -y tar"; exit 1; }

mkdir -p "$BASE_DIR"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "[1/3] Linux Artifact wird geladen ..."
curl -fL "$ARTIFACT_URL" -o "$TMP/fx.tar.xz"

echo "[2/3] Artifact wird entpackt ..."
tar -xJf "$TMP/fx.tar.xz" -C "$BASE_DIR"

echo "[3/3] FonicsScriptsDE Custom txAdmin/WebPanel wird installiert ..."
MONITOR="$BASE_DIR/alpine/opt/cfx-server/citizen/system_resources/monitor"
if [[ ! -d "$MONITOR" ]]; then
  MONITOR="$BASE_DIR/citizen/system_resources/monitor"
fi
if [[ ! -d "$MONITOR" ]]; then
  echo "Monitor-Verzeichnis wurde nicht gefunden. Linux Artifact-Struktur prüfen."
  exit 1
fi
cp -a "$CUSTOM_DIR/." "$MONITOR/"
chmod +x "$BASE_DIR/run.sh" 2>/dev/null || true

echo "Fertig: $BASE_DIR"
echo "Start: cd '$BASE_DIR' && ./run.sh +exec /pfad/zu/server.cfg"
